import context from "./itemContext.js";
import Player from "./player.js";
export default class Item{
    constructor(x=0,y=0){
        this.#x = x;
        this.#y = y;
        // this.#height = 0;
        this.#img = new Image();
        this.#isHitBtwRaP = false;
        this.#isHitBtwRaB = false;
        this.#isHitBtwDaB = false;
        this.#isHit = false;
        this.#width = this.#img.width;
        
    }
    deleteItem(){}
    update(){
        if(this.#isHit)
        this.deleteItem();
        for(let item of context.items){
            if(item.type =='R')
                console.log(item.img);//=========================================콘솔
            if(item === this)
                continue;
            //나와 items 내 있는 다른 item 과의 거리 
            let w = item.x-this.#x;
            let h = item.y-this.#y;
            let d = Math.sqrt(w*w+h*h);
            //if(item.type =='P')
            let sumR = this.width/2 + item.width/2; 
            if(d < sumR) {
              //  console.log("충돌");
                let typeOfItem = item.type;
                let typeOfMe = this.type;
                
                if(typeOfMe =='R')
                    if(typeOfItem == 'B')
                        this.#isHitBtwRaB = true;

                else if(typeOfMe == 'P'&& typeOfItem !='B')
                        this.#isHit =true;
            }
        }
    }    
   
    draw(){

    }
    get x(){
        return this.#x;
    }
    set x(x){
        this.#x= x;
    }   
    get y(){
        return this.#y;
    }
    set y(y){
        this.#y= y;
    }
    get img (){
        return this.#img;
    }
    set img (i){
        this.#img = i;
    }
    get width(){
        return this.#img.width;
    }
    get height(){
        return this.#img.height;
    }
    
    #x;
    #y;
    #width;
    #height;
    #img;
    #isHitBtwRaP;
    #isHitBtwRaB;
    #isHitBtwDaB;
    #isHitBtwDaP;
    #isHit;
    
}
