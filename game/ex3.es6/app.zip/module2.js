export default function test(){
    console.log("module2.test");
}
export function test1(){
    console.log("module2.test1");
}
